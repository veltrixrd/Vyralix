import type { Config } from "tailwindcss";
const config: Config = {
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}"],
  theme: { extend: { colors: { brand: "#1677FF", bg: "#101827", surface: "#1C293B", muted: "#94A3B8" } } },
  plugins: [],
};
export default config;
