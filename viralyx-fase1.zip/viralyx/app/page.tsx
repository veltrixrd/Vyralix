import Link from "next/link";
import Logo from "@/components/Logo";
const features = [
  ["Momentos destacados", "Detección de picos de interés en transmisiones (Fases 3–4)."],
  ["Clips verticales", "Formato 9:16 listo para redes (Fase 5)."],
  ["Subtítulos automáticos", "Transcripción y subtitulado sobre fuentes autorizadas (Fase 5)."],
  ["Cumplimiento", "Sin extracción no autorizada: respeta YouTube y los derechos de autor."],
];
export default function Home() {
  return (<div className="glow">
    <header className="mx-auto flex max-w-6xl items-center justify-between p-4"><Logo />
      <div className="flex gap-2 text-sm"><Link href="/login" className="px-3 py-2 text-muted hover:text-white">Entrar</Link>
      <Link href="/register" className="rounded-xl bg-brand px-4 py-2 font-semibold">Crear cuenta</Link></div></header>
    <main className="mx-auto max-w-6xl px-4 py-16 text-center md:py-28">
      <h1 className="text-4xl font-extrabold tracking-tight md:text-6xl">Convierte tus transmisiones en <span className="text-brand">clips virales</span></h1>
      <p className="mx-auto mt-5 max-w-2xl text-muted">VIRALYX analiza transmisiones desde fuentes autorizadas, detecta los mejores momentos y prepara clips verticales con subtítulos.</p>
      <Link href="/live" className="mt-8 inline-block rounded-xl bg-brand px-6 py-3 font-semibold">Probar VIRALYX LIVE</Link>
      <div className="mt-16 grid gap-4 text-left sm:grid-cols-2 lg:grid-cols-4">
        {features.map(([t, d]) => (<div key={t} className="rounded-2xl border border-white/10 bg-surface p-5"><h2 className="font-semibold">{t}</h2><p className="mt-2 text-sm text-muted">{d}</p></div>))}</div>
    </main></div>);
}
