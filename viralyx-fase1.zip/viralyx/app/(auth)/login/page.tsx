import Link from "next/link";
import Logo from "@/components/Logo";
export default function Login() {
  return (<main className="mx-auto grid min-h-screen max-w-md content-center gap-4 p-6"><Logo />
    <h1 className="text-2xl font-bold">Iniciar sesión</h1>
    <p className="rounded-2xl border border-white/10 bg-surface p-5 text-sm text-muted">El acceso con cuenta se activa en la <b className="text-white">Fase 2</b> (Supabase Auth). Hasta entonces no hay formulario, para no simular un inicio de sesión que no existe.</p>
    <Link href="/dashboard" className="text-sm text-brand">Ver el panel de la Fase 1 →</Link></main>);
}
