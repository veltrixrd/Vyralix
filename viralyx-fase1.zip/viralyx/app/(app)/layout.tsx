import Logo from "@/components/Logo";
import Nav from "@/components/Nav";
export default function AppLayout({ children }: { children: React.ReactNode }) {
  return (<div className="min-h-screen md:flex">
    <aside className="hidden w-56 shrink-0 border-r border-white/10 bg-surface p-4 md:block"><div className="mb-6"><Logo /></div><Nav vertical /></aside>
    <main className="flex-1 p-4 pb-24 md:p-8">{children}</main>
    <div className="fixed inset-x-0 bottom-0 border-t border-white/10 bg-surface p-2 md:hidden"><Nav /></div>
  </div>);
}
