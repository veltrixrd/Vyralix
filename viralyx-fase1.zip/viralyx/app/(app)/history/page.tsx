import Pending from "@/components/Pending";
export default function History() { return <Pending title="Historial de transmisiones" phase={2}>Se guardará en la base de datos cuando exista tu cuenta.</Pending>; }
