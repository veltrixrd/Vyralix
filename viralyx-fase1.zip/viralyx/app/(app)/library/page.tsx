import Pending from "@/components/Pending";
export default function Library() { return <Pending title="Biblioteca de clips" phase={5}>Aquí verás los clips verticales con subtítulos que se generen. Aún no existe ninguno.</Pending>; }
