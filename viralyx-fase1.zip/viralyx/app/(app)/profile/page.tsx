import Pending from "@/components/Pending";
export default function Profile() { return <Pending title="Perfil" phase={2}>Tus datos de usuario dependen de la autenticación.</Pending>; }
