import Link from "next/link";
export default function Dashboard() {
  return (<section className="space-y-4"><h1 className="text-2xl font-bold">Panel</h1>
    <div className="rounded-2xl border border-white/10 bg-surface p-5">
      <h2 className="font-semibold">Empieza con VIRALYX LIVE</h2>
      <p className="mt-2 text-sm text-muted">Pega un enlace público de YouTube y míralo con el reproductor oficial. Las estadísticas, clips e historial aparecerán aquí cuando existan datos reales (Fases 2 a 5).</p>
      <Link href="/live" className="mt-4 inline-block rounded-xl bg-brand px-4 py-2 text-sm font-semibold">Abrir VIRALYX LIVE</Link>
    </div></section>);
}
