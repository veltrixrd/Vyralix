import LivePlayer from "@/components/LivePlayer";
export default function Live() {
  return (<section className="space-y-4"><h1 className="text-2xl font-bold">VIRALYX LIVE</h1>
    <LivePlayer />
    <div className="rounded-2xl border border-white/10 bg-surface p-5 text-sm text-muted">
      <b className="text-white">Fuentes autorizadas.</b> VIRALYX no descarga ni extrae video de YouTube. El análisis y los clips (Fases 3 a 5) solo se harán sobre fuentes que el usuario demuestre controlar o tenga permiso de usar.</div></section>);
}
