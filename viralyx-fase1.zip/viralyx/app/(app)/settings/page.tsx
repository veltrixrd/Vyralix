import Pending from "@/components/Pending";
export default function Settings() { return <Pending title="Configuración" phase={2}>Las preferencias se guardan por cuenta.</Pending>; }
