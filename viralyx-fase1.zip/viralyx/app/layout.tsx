import type { Metadata, Viewport } from "next";
import "./globals.css";
export const metadata: Metadata = {
  title: "VIRALYX — Clips con IA de transmisiones en vivo",
  description: "Plataforma de IA para detectar momentos destacados y crear clips verticales con subtítulos desde fuentes autorizadas.",
};
export const viewport: Viewport = { themeColor: "#101827", width: "device-width", initialScale: 1 };
export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (<html lang="es"><body className="min-h-screen font-sans antialiased">{children}</body></html>);
}
