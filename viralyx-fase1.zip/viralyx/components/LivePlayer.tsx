"use client";
import { useState } from "react";
function parseId(raw: string): string | null {
  try {
    const u = new URL(raw.trim());
    const host = u.hostname.replace(/^www\.|^m\./, "");
    let id: string | null = null;
    if (host === "youtu.be") id = u.pathname.slice(1);
    else if (host === "youtube.com") {
      id = u.searchParams.get("v");
      const m = u.pathname.match(/^\/(live|embed|shorts)\/([^/?]+)/);
      if (!id && m) id = m[2];
    }
    return id && /^[\w-]{11}$/.test(id) ? id : null;
  } catch { return null; }
}
export default function LivePlayer() {
  const [value, setValue] = useState("");
  const [id, setId] = useState<string | null>(null);
  const [error, setError] = useState("");
  function load() {
    const parsed = parseId(value);
    if (!parsed) { setId(null); setError("Enlace de YouTube no válido."); return; }
    setError(""); setId(parsed);
  }
  return (<div className="space-y-3 rounded-2xl border border-white/10 bg-surface p-5">
    <label htmlFor="yt" className="text-sm font-semibold">Enlace público de YouTube</label>
    <div className="flex flex-col gap-2 sm:flex-row">
      <input id="yt" value={value} onChange={(e) => setValue(e.target.value)} placeholder="https://www.youtube.com/watch?v=..." className="w-full rounded-xl border border-white/10 bg-bg px-3 py-2 text-sm outline-none focus:border-brand" />
      <button onClick={load} className="rounded-xl bg-brand px-4 py-2 text-sm font-semibold">Cargar</button></div>
    {error && <p className="text-sm text-red-400">{error}</p>}
    {id && <div className="aspect-video overflow-hidden rounded-xl"><iframe className="h-full w-full" src={`https://www.youtube-nocookie.com/embed/${id}`} title="Reproductor oficial de YouTube" allow="accelerometer; autoplay; encrypted-media; picture-in-picture" allowFullScreen /></div>}
  </div>);
}
