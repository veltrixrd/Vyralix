export default function Pending({ title, phase, children }: { title: string; phase: number; children: React.ReactNode }) {
  return (<section className="space-y-4">
    <h1 className="text-2xl font-bold">{title}</h1>
    <div className="rounded-2xl border border-white/10 bg-surface p-5">
      <span className="rounded-full bg-brand/20 px-3 py-1 text-xs font-semibold text-brand">Se activa en la Fase {phase}</span>
      <p className="mt-3 text-sm text-muted">{children}</p>
    </div></section>);
}
