import Link from "next/link";
export default function Logo() {
  return (<Link href="/" className="flex items-center gap-2 text-lg font-bold tracking-wide">
    <span className="grid h-8 w-8 place-items-center rounded-lg bg-brand text-white">V</span>VIRALYX</Link>);
}
