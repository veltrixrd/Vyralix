"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
const items = [
  ["/dashboard", "Panel"], ["/live", "LIVE"], ["/library", "Clips"],
  ["/history", "Historial"], ["/profile", "Perfil"], ["/settings", "Ajustes"],
] as const;
export default function Nav({ vertical }: { vertical?: boolean }) {
  const path = usePathname();
  return (<nav className={vertical ? "flex flex-col gap-1" : "flex justify-around"}>
    {items.map(([href, label]) => (
      <Link key={href} href={href} className={`rounded-lg px-3 py-2 text-sm ${path === href ? "bg-brand text-white" : "text-muted hover:text-white"}`}>{label}</Link>
    ))}</nav>);
}
