# VIRALYX — Arquitectura
- Web (Next.js en Vercel): UI, auth, API ligera. Nunca procesa video.
- Supabase: Auth + Postgres (tablas `jobs`, `clips`, `streams`) + cola basada en la tabla `jobs`.
- Worker (Fases 4–5): proceso separado que consulta `jobs` y escribe resultados. Corre fuera de Vercel (GitHub Actions o un host gratuito compatible).
- Contrato web↔worker: filas de `jobs` con estado (queued/running/done/failed).
