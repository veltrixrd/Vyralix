-- BORRADOR DE LA FASE 2. NO APLICADO. Ejecutar solo en un proyecto Supabase NUEVO de VIRALYX, nunca en "Veltrix".
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text, created_at timestamptz not null default now());
create table public.streams (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  youtube_video_id text not null, title text,
  source_authorized boolean not null default false,
  created_at timestamptz not null default now());
create table public.jobs (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  stream_id uuid references public.streams(id) on delete cascade,
  status text not null default 'queued' check (status in ('queued','running','done','failed')),
  error text, created_at timestamptz not null default now());
create table public.clips (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  stream_id uuid references public.streams(id) on delete set null,
  start_s numeric not null, end_s numeric not null, file_path text,
  created_at timestamptz not null default now());
alter table public.profiles enable row level security;
alter table public.streams enable row level security;
alter table public.jobs enable row level security;
alter table public.clips enable row level security;
create policy "own profile" on public.profiles for all using (id = auth.uid()) with check (id = auth.uid());
create policy "own streams" on public.streams for all using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy "own jobs read" on public.jobs for select using (user_id = auth.uid());
create policy "own clips" on public.clips for all using (user_id = auth.uid()) with check (user_id = auth.uid());
